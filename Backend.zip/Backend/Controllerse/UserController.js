export {};
// const {Request,Responce} from "express"
// export default Show=(req:Request,res:Responce)=>{
//     res.send("Hello World")
// }
